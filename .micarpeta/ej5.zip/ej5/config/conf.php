<?php

$aGenero = array("Hombre", "Mujer", "Otro");
$aVehiculos = array("Bicicleta", "Coche", "Patinete");
$aColores = array( 
    array("codigo" => 1, "color" => "rojo"), 
    array("codigo" => 2, "color" => "azul"),
    array("codigo" => 3, "color" => "verde"));
$aCoches = array("BMW", "Audi", "Volvo", "Seat");
$aIdiomas = array("B1", "B2", "C1");

$aErrores = array();
?>