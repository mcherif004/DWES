<?php
$aTests = array(
array("idTest"=>1,
"respuestas"=>array(["a", "c"],["a", "b"],["a", "c"], ["b", "d"], "Falso"),
"preguntas"=>array(
                    array("idPregunta"=>1,
                        "Pregunta"=>"1. ¿Cuáles de los siguientes países estan en América del Sur?",
                        "respuestas"=>array("a) Brasil","b) México","c) Argentina","d) España")
						),
                    array("idPregunta"=>2,
                        "Pregunta"=>"2. ¿Qué océanos rodean al continente africano?",
                        "respuestas"=>array("a) Atlántico","b) Índico","c) Pacífico", "d) Ártico")
						),
                    array("idPregunta"=>3,
                        "Pregunta"=>"3. ¿Cuáles de las siguientes son montañas o sistemas rocosos ?",
                        "respuestas"=>array("a) Himalaya","b) Amazonas","c) Andes", "d) Río Nilo")
						),
                    array("idPregunta"=>4,
                        "Pregunta"=>"4. ¿Qué continentes cruzan el Ecuador?",
                        "respuestas"=>array("a) América del Norte","b) África","c) Asia", "d) Oceanía")
						),
                    array("idPregunta"=>5,
                        "Preg0unta"=>"5. El río Amazonas es el más largo del mundo",
                        "respuestas"=>array("Verdadero","Falso")
						))
),
array("idTest"=>2,
"respuestas"=>array(["a", "c"],["a", "b"],["a", "c"], ["b", "d"], "Falso"),
"preguntas"=>array(
                    array("idPregunta"=>1,
                        "Pregunta"=>"1. ¿Cuáles de los siguientes países estan en América del Sur?",
                        "respuestas"=>array("a) Brasil","b) México","c) Argentina","d) España")
						),
                    array("idPregunta"=>2,
                        "Pregunta"=>"2. ¿Qué océanos rodean al continente africano?",
                        "respuestas"=>array("a) Atlántico","b) Índico","c) Pacífico", "d) Ártico")
						),
                    array("idPregunta"=>3,
                        "Pregunta"=>"3. ¿Cuáles de las siguientes son montañas o sistemas rocosos ?",
                        "respuestas"=>array("a) Himalaya","b) Amazonas","c) Andes", "d) Río Nilo")
						),
                    array("idPregunta"=>4,
                        "Pregunta"=>"4. ¿Qué continentes cruzan el Ecuador?",
                        "respuestas"=>array("a) América del Norte","b) África","c) Asia", "d) Oceanía")
						),
                    array("idPregunta"=>5,
                        "Preg0unta"=>"5. El río Amazonas es el más largo del mundo",
                        "respuestas"=>array("Verdadero","Falso")
						))
),array("idTest"=>3,
"respuestas"=>array(["a", "c"],["a", "b"],["a", "c"], ["b", "d"], "Falso"),
"preguntas"=>array(
                    array("idPregunta"=>1,
                        "Pregunta"=>"1. ¿Cuáles de los siguientes países estan en América del Sur?",
                        "respuestas"=>array("a) Brasil","b) México","c) Argentina","d) España")
						),
                    array("idPregunta"=>2,
                        "Pregunta"=>"2. ¿Qué océanos rodean al continente africano?",
                        "respuestas"=>array("a) Atlántico","b) Índico","c) Pacífico", "d) Ártico")
						),
                    array("idPregunta"=>3,
                        "Pregunta"=>"3. ¿Cuáles de las siguientes son montañas o sistemas rocosos ?",
                        "respuestas"=>array("a) Himalaya","b) Amazonas","c) Andes", "d) Río Nilo")
						),
                    array("idPregunta"=>4,
                        "Pregunta"=>"4. ¿Qué continentes cruzan el Ecuador?",
                        "respuestas"=>array("a) América del Norte","b) África","c) Asia", "d) Oceanía")
						),
                    array("idPregunta"=>5,
                        "Preg0unta"=>"5. El río Amazonas es el más largo del mundo",
                        "respuestas"=>array("Verdadero","Falso")
						))
),);
